java -cp saxon9he.jar net.sf.saxon.Transform -s:messages.xml -xsl:messages.xsl -o:res.html





java -cp saxon9he.jar net.sf.saxon.Transform -s:messages.xml -xsl:messages.xsl




commandes pour le labo 2:

java -cp saxon9he.jar net.sf.saxon.Transform -s:../XML/planification.xml -xsl:../XSL/client.xsl -o:../XSL/html_generated/*

java -cp saxon9he.jar net.sf.saxon.Transform -s:../XML/planification.xml -xsl:../XSL/medialocal.xsl -o:../XSL/medialocal/*

