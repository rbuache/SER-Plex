D�composition des dossiers:


Workspace : il s'agit du workspace eclipse directement ouvrable.

	Office : contient l'application de l'office du cin�ma.
		Cette application contient aussi les xml et dtd officiel.
		XML
		DTD
	Admin  : contient l'application de l'administrateur.
	Media  : contient l'application des m�dia.
	RMI    : code commun des interfaces rmi

Tools : contient les outils pour ex�cuter les xml.
	Le fichier readme contient les commandes.

XSL: contient les xsl pour g�n�ration media et client.
	Deux dossiers avec postfixe _generated contiennent les r�sultats de l'ex�cution des xsl.

XML: contient la base de donn�e de l'administrateur cin�ma

DTD: contient les dtd cr��es � la premi�re �tape.

	